import Foundation

enum Size:String{
    case small,medium,large
}

Size.small.rawValue

enum Temperature:String{
    case cold = " Ice"
    case roomTemp = " Room Temperature"
    case warm = " Warm"
    case hot = " Hot"
}

Temperature.cold.rawValue

enum Beverage{
    case water
    case juice
    case cocoa
    case espresso
}

func drinkFormatter(drink:Beverage) -> String{
var drinkName = ""
switch drink{
    case  .water:
        drinkName = " Water"
    case  .juice:
        drinkName = " Juice"
    case .cocoa:
        drinkName = " Chocolate"
    case .espresso:
        drinkName = " Espresso"
    }
return drinkName
}

drinkFormatter(drink: .water)
